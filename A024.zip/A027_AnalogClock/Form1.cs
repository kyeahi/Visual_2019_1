﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A027_AnalogClock
{
    public partial class Form1 : Form
    {
        Timer t = new Timer();
        Graphics g;

        public Form1()
        {
            InitializeComponent();
            panel1.Size = new Size(300, 300);
            ClientSize = new Size(300, 300 + menuStrip1.Height);

            t.Interval = 1000; // 1초
            t.Tick += T_Tick;
            t.Start();
            g = panel1.CreateGraphics();

        }

        private void T_Tick(object sender, EventArgs e)
        {
            panel1.Refresh();
            int sec = DateTime.Now.Second;
            double secDeg = 6 * sec;  // 1초당 6도씩
            double secRad = secDeg * Math.PI / 180; // 라디안 값
            double secX = 120 * Math.Sin(secRad);
            double secY = 120 * Math.Cos(secRad);
            int x = 150 + (int)secX;
            int y = 150 - (int)secY;

            g.DrawLine(new Pen(Color.Blue), new Point(150, 150),
                new Point(x, y));

            int min = DateTime.Now.Minute;
            double minDeg = 6 * min;  // 1분당 6도씩
            double minRad = minDeg * Math.PI / 180; // 라디안 값
            double minX = 100 * Math.Sin(minRad);
            double minY = 100 * Math.Cos(minRad);
             x = 150 +(int) minX;
             y = 150 -(int) minY;

            g.DrawLine(new Pen(Color.Red), new Point(150, 150),
                new Point(x, y));

            int hour = DateTime.Now.Hour;
            double hourDeg = 30 *hour+0.5*min;  // 1시간 당 30도씩
            double hourRad = hourDeg * Math.PI / 180; // 라디안 값
            double hourX = 80 * Math.Sin(hourRad);
            double hourY = 80 * Math.Cos(hourRad);
            x = 150 + (int)hourX;
            y = 150 - (int)hourY;

            g.DrawLine(new Pen(Color.Black), new Point(150, 150),
                new Point(x, y));
        }
    }
}
