﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _23_Class
{
    class CarP
    {
        public string Name { get; set; }
        public int Number { get; set; }
        public int Year { get; set; }

        public CarP()
        {

        }
        public CarP(string name, int number, int year)
        {
            Name = name;
            Number = number;
            Year = year;
        }
        public void Print() //생성자가 아니라 리턴값이 있어야함 //void
        {
            Console.WriteLine("Name: {0}, Number:{1}, Year:{2}",
                Name, Number,Year);
        }
    }
    class Car
    {
        private string name;
        private int number;
        private int year;

        public void setName(string s) //메소드 생성
        {
            name = s;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Car car = new Car();
            car.setName( "audi");

            CarP x = new CarP(); //이 객체를 위해서 빈 생성자를 만듦
            x.Name = "audi";
            x.Number = 1234;
            x.Year = 2019;

            CarP y = new CarP("benx", 7878, 2019);

            x.Print();
            y.Print();

        }
    }
}
