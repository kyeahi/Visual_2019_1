﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a = new int[10];
            List<int> b = new List<int>(); //괄호 안의 데이터 형이 저장됨
            //Car car =new Car(); 클래스 객체 = new 객체유형;

            Random r = new Random(); //r은 랜덤 객체
            //r.Next()가 랜덤값을 생성
            //리스트나 배열은 데이터를 저장
            //배열은 개수한정, 리스트는 개수 한정없음

            for (int i = 0; i < 10; i++)
            {
                a[i] = r.Next(100); //배열 스타일
                // b[i] = r.Next(100); //이렇게 쓰면 안된다
                b.Add(r.Next(100));

                //a와 b에 랜덤값을 넣는다.
            }

            PrintIntArray(a);
            PrintIntList(b);

            string[] s1 = new string[10];
            List<string> s2 = new List<string>();

            s1[0] = "abcd";
            s1[1] = "efgh";
            s1[2] = "egg";

            s2.Add("apple");
            s2.Add("banana");
            s2.Add("carrot");

            foreach (var item in s1)
                Console.WriteLine(item);
            Console.WriteLine();

            foreach (var item in s2)
                Console.WriteLine(item);
            Console.WriteLine();

            //정렬
            //배열: Array.Sort()
            //리스트: 객체.Sort()
            Array.Sort(a); //Static 메소드이므로
            // a.Sort(); //이렇게 쓸 수없다

            b.Sort();//객체, 즉 리스트 이름으로 사용한다

            Array.Sort(s1);
            s2.Sort();


            foreach (var item in a)
            {
                Console.WriteLine(item + "  "); //a에 있는 값을 출력
            }
            Console.WriteLine();

            foreach (var item in b)
            {
                Console.WriteLine(item + "  "); //a에 있는 값을 출력
            }
            Console.WriteLine();

            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(b[i] + "  "); //배열형태의 사용법
            }
            Console.WriteLine();


            Print(s1);
            PrintList(s2);
        }

        private static void PrintIntList(List<int> b)
        {
            foreach (var item in b)
            {
                Console.WriteLine(item + "  "); //a에 있는 값을 출력
            }
            Console.WriteLine();
        }

        private static void NewMethod(List<int> b)
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(b[i] + "  "); //배열형태의 사용법
            }
            Console.WriteLine();
        }

        private static void PrintIntArray(int[] a)
        {
            foreach (var item in a)
            {
                Console.WriteLine(item + "  "); //a에 있는 값을 출력
            }
            Console.WriteLine();
        }

        private static void PrintList(List<string> s2)
        {
            foreach (var item in s2)
                Console.WriteLine(item);
            Console.WriteLine();
        }

        private static void Print(string[] s)
        {
            foreach (var item in s)
                Console.WriteLine(item);
            Console.WriteLine();
        }
    }
}
