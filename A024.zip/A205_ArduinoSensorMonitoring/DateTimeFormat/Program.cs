﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DateTimeFormat
{
  class Program
  {
    static void Main(string[] args)
    {
      Console.WriteLine(DateTime.Now.ToString());
      Console.WriteLine(DateTime.Now.ToLongTimeString());
      Console.WriteLine(DateTime.Now.ToShortTimeString());
      Console.WriteLine(DateTime.Now.ToString("u"));
      Console.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
    }
  }
}
